#!/usr/bin/python
# coding: utf-8

import reptil

reptil1 = reptil.Reptil("Víbora")
reptil2 = reptil.Reptil("Cocodrilo")

reptil1.avanzar()
reptil2.avanzar()