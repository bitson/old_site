#!/usr/bin/python
# coding: utf-8

__author__ = "leo"
__date__ = "11/05/2014"

import persona
import reptil

sujeto = persona.Persona("Lucas")
animal = reptil.Reptil("Pitón")

sujeto.avanzar()
animal.avanzar()