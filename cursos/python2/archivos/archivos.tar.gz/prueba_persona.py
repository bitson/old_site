#!/usr/bin/python
# coding: utf-8

import persona

sujeto1 = persona.Persona("Juan")
sujeto2 = persona.Persona("Pedro")

sujeto1.avanzar()
sujeto2.avanzar()
